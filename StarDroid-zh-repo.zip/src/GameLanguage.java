package org.openbw.androidtest;

import java.nio.charset.Charset;
import java.io.File;
import java.util.Locale;

/** The archive's encoding and the player's UI language are independent. */
final class GameLanguage {
  static final Charset WESTERN = Charset.forName("windows-1252");
  static final Charset RUSSIAN = Charset.forName("windows-1251");
  /** Locally patched Simplified Chinese tables are stored as plain UTF-8. */
  static final Charset CHINESE = Charset.forName("UTF-8");
  static volatile boolean russianData;
  static volatile boolean chineseData;

  static Charset charset() { return chineseData ? CHINESE : russianData ? RUSSIAN : WESTERN; }

  static String decode(byte[] data) {
    if (data == null) return "";
    // Locally patched maps and tables are UTF-8 while the original data is
    // single-byte, so decide per string instead of per install.
    if (!chineseData && looksChinese(data)) return new String(data, CHINESE);
    return new String(data, charset());
  }

  static String decode(byte[] data, int offset, int length) {
    if (data == null || offset < 0 || length < 0 || offset + length > data.length) return "";
    if (!chineseData && looksChinese(data, offset, length)) return new String(data, offset, length, CHINESE);
    return new String(data, offset, length, charset());
  }

  /** True when the bytes are well-formed UTF-8 and contain Han ideographs. */
  static boolean looksChinese(byte[] table, int offset, int length) {
    if (table == null || length < 3) return false;
    int han = 0, i = offset, end = offset + length;
    while (i < end) {
      int b = table[i] & 255;
      if (b < 0x80) { i++; continue; }
      int extra = (b & 0xE0) == 0xC0 ? 1 : (b & 0xF0) == 0xE0 ? 2 : (b & 0xF8) == 0xF0 ? 3 : -1;
      if (extra < 0 || i + extra >= end) return false;
      int cp = b & (0x3F >> extra);
      for (int k = 1; k <= extra; k++) {
        int c = table[i + k] & 255;
        if ((c & 0xC0) != 0x80) return false;
        cp = (cp << 6) | (c & 0x3F);
      }
      if (cp >= 0x3400 && cp <= 0x9FFF) han++;
      i += extra + 1;
    }
    return han > 0;
  }

  static boolean looksChinese(byte[] table) {
    return table != null && looksChinese(table, 0, table.length);
  }

  /** A Chinese table is well-formed UTF-8 carrying Han ideographs; the
   * original tables are single-byte and never decode that way. */
  static boolean isChinese(byte[] table) {
    if (table == null || table.length < 64 || table.length > 1024 * 1024) return false;
    int han = 0, i = 0;
    while (i < table.length) {
      int b = table[i] & 255;
      if (b < 0x80) { i++; continue; }
      int extra = (b & 0xE0) == 0xC0 ? 1 : (b & 0xF0) == 0xE0 ? 2 : (b & 0xF8) == 0xF0 ? 3 : -1;
      if (extra < 0 || i + extra >= table.length) return false;
      int cp = b & (0x3F >> extra);
      for (int k = 1; k <= extra; k++) {
        int c = table[i + k] & 255;
        if ((c & 0xC0) != 0x80) return false;
        cp = (cp << 6) | (c & 0x3F);
      }
      if (cp >= 0x3400 && cp <= 0x9FFF) han++;
      i += extra + 1;
    }
    return han >= 20;
  }

  static boolean isRussian(byte[] table) {
    if (table == null || table.length < 6 || table.length > 1024 * 1024) return false;
    int count = (table[0] & 255) | (table[1] & 255) << 8;
    if (count < 100 || 2 + count * 2 > table.length) return false;
    StringBuilder names = new StringBuilder();
    for (int i = 0; i < Math.min(count, 228); i++) {
      int at = 2 + i * 2, p = (table[at] & 255) | (table[at + 1] & 255) << 8;
      if (p < 2 + count * 2 || p >= table.length) continue;
      int end = p; while (end < table.length && end - p < 200 && table[end] != 0) end++;
      names.append(new String(table, p, end - p, RUSSIAN)).append('\n');
    }
    String text = names.toString().toLowerCase(Locale.ROOT); int matches = 0;
    for (String word : new String[]{"морпех", "пехота", "призрак", "привидение", "трутень", "зерг", "терран", "зонд", "зилот", "гидралиск"})
      if (text.contains(word)) matches++;
    return matches >= 3;
  }

  static boolean installedRussian(File directory) {
    for (String name : new String[]{"patch_rt.mpq", "BROODAT.MPQ", "STARDAT.MPQ"}) {
      File archive = new File(directory, name);
      if (!archive.isFile()) continue;
      try {
        byte[] table = NativeBridge.archiveText(archive.getPath());
        if (table != null && table.length > 0) return isRussian(table);
      } catch (RuntimeException ignored) { }
    }
    return false;
  }

  static boolean installedChinese(File directory) {
    for (String name : new String[]{"patch_rt.mpq", "STARDAT.MPQ", "BROODAT.MPQ"}) {
      File archive = new File(directory, name);
      if (!archive.isFile()) continue;
      try {
        byte[] table = NativeBridge.archiveText(archive.getPath());
        if (table != null && isChinese(table)) return true;
      } catch (RuntimeException ignored) { }
    }
    return false;
  }

  static int glyphCode(int code) {
    if (code < 128) return code;
    // Chinese glyphs have no original bitmap letterform: fall through to the
    // styled installed font instead of the 256-entry FONT range.
    if (chineseData) return -1;
    String letter = Character.toString((char) code);
    byte[] encoded = letter.getBytes(charset());
    return encoded.length == 1 && new String(encoded, charset()).equals(letter) ? encoded[0] & 255 : -1;
  }
}
