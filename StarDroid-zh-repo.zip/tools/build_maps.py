"""Rebuild every .scm/.scx of a map pack with its translated STR table."""
import json
import os
import shutil
import sys
import zipfile

sys.path.insert(0, '/root/scwork')
import mapzh

SRC = '/root/.dsh/attachments/v1/files/6f/6fa03de25ba2d2785e088dcf538ff19523621a2a27b861173bd7ad3ed99a890d/Maps.zip'
ZH_DIR = '/sdcard/DSHA WorkZone/work/maps_zh'
OUT_DIR = '/root/scwork/out_maps'
WORK = '/root/scwork/workmap'


def load_mapping():
    index = json.load(open('/root/scwork/map_index.json'))
    translated = {}
    sources = ['%s/src%02d.zh.tsv' % (ZH_DIR, i) for i in range(1, 13)]
    sources += ['/sdcard/DSHA WorkZone/work/maps_zh2/m%02d.zh.tsv' % i for i in range(1, 9)]
    for path in sources:
        if not os.path.isfile(path):
            print('missing translation chunk', path)
            continue
        for line in open(path, encoding='utf-8'):
            line = line.rstrip('\n')
            if not line:
                continue
            key, text = line.split('\t', 1)
            translated[int(key)] = text.replace('\\n', '\n')
    mapping = {}
    for key, english in index.items():
        zh = translated.get(int(key))
        if zh is None:
            continue
        k = english.replace('\t', ' ').strip()
        if k:
            mapping[k] = zh
    return mapping, len(translated)


def main():
    mapping, count = load_mapping()
    print('translated strings', count, 'mapping keys', len(mapping))
    if os.path.isdir(OUT_DIR):
        shutil.rmtree(OUT_DIR)
    os.makedirs(OUT_DIR)
    os.makedirs(WORK, exist_ok=True)
    z = zipfile.ZipFile(SRC)
    names = [n for n in z.namelist() if n.lower().endswith(('.scm', '.scx'))]
    stats = {'inplace': 0, 'append': 0, 'no-str': 0, 'skipped': 0, 'error': 0}
    replaced = 0
    for n in names:
        target = os.path.join(OUT_DIR, n)
        os.makedirs(os.path.dirname(target), exist_ok=True)
        temp = os.path.join(WORK, 'map.tmp')
        open(temp, 'wb').write(z.read(n))
        before = os.path.getsize(temp)
        counter = [0]
        try:
            mode = mapzh.localize(temp, mapping, counter)
        except Exception as error:
            stats['error'] += 1
            print('ERR', n, error)
            continue
        replaced += counter[0]
        stats[mode] = stats.get(mode, 0) + 1
        shutil.move(temp, target)
        if counter[0] == 0:
            stats['skipped'] += 1
    print('maps', len(names), 'strings replaced', replaced, stats)
    out_zip = '/root/scwork/Maps-zh.zip'
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as out:
        for root, _, files in os.walk(OUT_DIR):
            for name in sorted(files):
                full = os.path.join(root, name)
                rel = os.path.relpath(full, OUT_DIR).replace(os.sep, '/')
                out.write(full, rel)
    print('zip', out_zip, os.path.getsize(out_zip) // 1024 // 1024, 'MB')


if __name__ == '__main__':
    main()
