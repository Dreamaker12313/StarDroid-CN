"""Patch localized campaign maps and story texts into the classic archives."""
import json
import os
import sys

sys.path.insert(0, '/root/scwork')
import mapzh
import mpq_patch

MISSIONS = '/sdcard/DSHA WorkZone/work/src/StarDroid-main/app/src/main/assets/native/missions.json'
STORY_NAMES = None


def build_mapping():
    index = json.load(open('/root/scwork/camp_index.json'))
    translated = {}
    for i in range(1, 15):
        path = '/sdcard/DSHA WorkZone/work/camp_zh/c%02d.zh.tsv' % i
        if not os.path.isfile(path):
            print('missing chunk', path)
            continue
        for line in open(path, encoding='utf-8'):
            line = line.rstrip('\n')
            if not line:
                continue
            key, text = line.split('\t', 1)
            translated[int(key)] = text.replace('\\n', '\n')
    mapping = {}
    for key, english in index.items():
        zh = translated.get(int(key))
        if zh is None:
            continue
        k = english.replace('\t', ' ').strip()
        if k:
            mapping[k] = zh
    return mapping, len(translated)


def main():
    mapping, count = build_mapping()
    print('campaign strings translated', count, 'keys', len(mapping))
    if count == 0:
        raise SystemExit('no translations yet')
    missions = json.load(open(MISSIONS))
    patches = {'sc': [], 'bw': []}
    total = 0
    for m in missions:
        tag = 'sc' if m.get('game') == 'starcraft' else 'bw'
        chk_path = '/root/scwork/campaign/%s.chk' % m['id']
        if not os.path.isfile(chk_path):
            continue
        chk = open(chk_path, 'rb').read()
        chunks = mapzh.split_chunks(chk)
        changed = False
        for chunk in chunks:
            if chunk[0] == b'STR ':
                chunk[1] = bytearray(mapzh.rebuild_str(chunk[1], mapping, [0]))
                changed = True
        if not changed:
            continue
        name = m['prefix'].rstrip('/').replace('/', '\\') + '\\staredit\\scenario.chk'
        patches[tag].append((name, mapzh.join_chunks(chunks)))
        total += 1
    # story texts
    for f in sorted(os.listdir('/root/scwork/story_zh')):
        tag = f[:2]
        name = 'rez\\' + f[3:]
        patches[tag].append((name, open('/root/scwork/story_zh/' + f, 'rb').read()))
    print('missions patched', total, 'sc', len(patches['sc']), 'bw', len(patches['bw']))
    for tag, archive in (('sc', '/root/scwork/StarCraft.mpq'), ('bw', '/root/scwork/BroodWar_zh.mpq')):
        if not patches[tag]:
            continue
        print('patching', archive, len(patches[tag]), 'entries')
        for name, data in patches[tag]:
            try:
                mpq_patch.patch(archive, name, data)
            except SystemExit as e:
                print('  skip', name, e)
    print('done')


if __name__ == '__main__':
    main()
