"""Minimal MPQ (Storm) reader/writer for classic StarCraft archives."""
import struct, zlib, bz2, os

# ---------------------------------------------------------------- hash table
_crypt = None

def _build_crypt():
    global _crypt
    if _crypt is not None:
        return _crypt
    table = [0] * 0x500
    seed = 0x00100001
    for index1 in range(0x100):
        index2 = index1
        for _ in range(5):
            seed = (seed * 125 + 3) % 0x2AAAAB
            temp1 = (seed & 0xFFFF) << 0x10
            seed = (seed * 125 + 3) % 0x2AAAAB
            temp2 = (seed & 0xFFFF)
            table[index2] = (temp1 | temp2) & 0xFFFFFFFF
            index2 += 0x100
    _crypt = table
    return table


def _hash(data, htype):
    """MPQ hash. htype: 0=table offset, 1=name A, 2=name B, 3=table key."""
    t = _build_crypt()
    if isinstance(data, str):
        data = data.encode('latin-1')
    s1, s2 = 0x7FED7FED, 0xEEEEEEEE
    for ch in data:
        if not isinstance(ch, int):
            ch = ord(ch)
        if 97 <= ch <= 122:
            ch -= 32
        s1 = (t[(htype << 8) + ch] ^ (s1 + s2)) & 0xFFFFFFFF
        s2 = (ch + s1 + s2 + (s2 << 5) + 3) & 0xFFFFFFFF
    return s1


def _step(seed1):
    return ((((~seed1) << 0x15) + 0x11111111) | (seed1 >> 0x0B)) & 0xFFFFFFFF


def _decrypt(data, key):
    t = _build_crypt()
    seed1, seed2 = key, 0xEEEEEEEE
    out = bytearray(data)
    for i in range(0, len(data) - 3, 4):
        seed2 = (seed2 + t[0x400 + (seed1 & 0xFF)]) & 0xFFFFFFFF
        value = struct.unpack_from('<I', data, i)[0]
        value = (value ^ (seed1 + seed2)) & 0xFFFFFFFF
        seed1 = _step(seed1)
        seed2 = (value + seed2 + (seed2 << 5) + 3) & 0xFFFFFFFF
        struct.pack_into('<I', out, i, value)
    return bytes(out)


def _encrypt(data, key):
    t = _build_crypt()
    seed1, seed2 = key, 0xEEEEEEEE
    out = bytearray(data)
    for i in range(0, len(data) - 3, 4):
        seed2 = (seed2 + t[0x400 + (seed1 & 0xFF)]) & 0xFFFFFFFF
        value = struct.unpack_from('<I', data, i)[0]
        enc = (value ^ (seed1 + seed2)) & 0xFFFFFFFF
        seed1 = _step(seed1)
        seed2 = (value + seed2 + (seed2 << 5) + 3) & 0xFFFFFFFF
        struct.pack_into('<I', out, i, enc)
    return bytes(out)


class BlockEntry:
    __slots__ = ('offset', 'compressed_size', 'size', 'flags')

    def __init__(self, offset=0, compressed_size=0, size=0, flags=0):
        self.offset, self.compressed_size, self.size, self.flags = offset, compressed_size, size, flags

    def pack(self):
        return struct.pack('<IIII', self.offset, self.compressed_size, self.size, self.flags)


class HashEntry:
    __slots__ = ('name1', 'name2', 'locale', 'platform', 'block')

    def __init__(self, name1=0xFFFFFFFF, name2=0xFFFFFFFF, locale=0, platform=0, block=0xFFFFFFFF):
        self.name1, self.name2, self.locale, self.platform, self.block = name1, name2, locale, platform, block

    def pack(self):
        return struct.pack('<IIHHI', self.name1, self.name2, self.locale, self.platform, self.block)


FILE_EXISTS = 0x80000000
SINGLE_UNIT = 0x01000000
COMPRESSED = 0x00000200
MPQ_FILE_IMPLODE = 0x00000100
MPQ_FILE_COMPRESS = 0x00000200
MPQ_FILE_ENCRYPTED = 0x00010000
MPQ_FILE_FIX_KEY = 0x00020000
MPQ_FILE_SINGLE_UNIT = 0x01000000
MPQ_FILE_SECTOR_CRC = 0x04000000


class MPQ:
    def __init__(self, path):
        self.path = path
        self.f = open(path, 'rb')
        self.size = os.fstat(self.f.fileno()).st_size
        self._read_header()

    def _read_header(self):
        f = self.f
        # find header (may be at a nonzero offset if prefixed)
        self.header_offset = 0
        self.f.seek(0)
        magic = self.f.read(4)
        if magic != b'MPQ\x1a':
            raise ValueError('not an MPQ archive: %r' % magic)
        f.seek(self.header_offset)
        data = f.read(32)
        (magic, hsize, asize, version, sector_shift, hpos, bpos, hcount, bcount) = struct.unpack('<4sIIHHIIII', data)
        self.version = version
        self.sector_size = 512 << sector_shift
        self.hash_pos, self.block_pos = hpos, bpos
        self.hash_count, self.block_count = hcount, bcount
        f.seek(hpos)
        raw = f.read(hcount * 16)
        dec = _decrypt(raw, _hash('(hash table)', 3))
        self.hash_table = []
        for i in range(hcount):
            n1, n2, loc, plat, blk = struct.unpack_from('<IIHHI', dec, i * 16)
            self.hash_table.append(HashEntry(n1, n2, loc, plat, blk))
        f.seek(bpos)
        raw = f.read(bcount * 16)
        dec = _decrypt(raw, _hash('(block table)', 3))
        self.block_table = []
        for i in range(bcount):
            off, csize, usize, flags = struct.unpack_from('<IIII', dec, i * 16)
            self.block_table.append(BlockEntry(off, csize, usize, flags))

    # ------------------------------------------------------------ lookup
    def find(self, name):
        name = name.replace('/', '\\')
        h0 = _hash(name.encode('latin-1'), 0)
        h1 = _hash(name.encode('latin-1'), 1)
        h2 = _hash(name.encode('latin-1'), 2)
        start = h0 & (self.hash_count - 1)
        i = start
        while True:
            e = self.hash_table[i]
            if e.block != 0xFFFFFFFF and e.name1 == h1 and e.name2 == h2:
                return e
            if e.block == 0xFFFFFFFF and e.name1 == 0xFFFFFFFF and e.name2 == 0xFFFFFFFF:
                return None
            i = (i + 1) & (self.hash_count - 1)
            if i == start:
                return None

    def exists(self, name):
        return self.find(name) is not None

    def read_file(self, name):
        return self.read_entry(name)[1]

    def file_key(self, name, b):
        key = _hash(name.split('\\')[-1].encode('latin-1'), 3)
        if b.flags & MPQ_FILE_FIX_KEY:
            key = ((key + b.offset) ^ b.size) & 0xFFFFFFFF
        return key

    def read_entry(self, name):
        e = self.find(name)
        if e is None:
            raise KeyError(name)
        b = self.block_table[e.block]
        if b.size == 0:
            return b, b''
        self.f.seek(b.offset)
        raw = self.f.read(b.compressed_size)
        if len(raw) != b.compressed_size:
            raise ValueError('truncated file data: %s' % name)
        key = self.file_key(name, b) if b.flags & MPQ_FILE_ENCRYPTED else None
        if b.flags & MPQ_FILE_SINGLE_UNIT:
            data = _decrypt(raw, key) if key is not None else raw
            if b.flags & MPQ_FILE_COMPRESS:
                data = decompress_sector(data, b.size)
            return b, data[:b.size]
        # sectorized
        n = (b.size + self.sector_size - 1) // self.sector_size
        if n == 1 and b.compressed_size == b.size and not (b.flags & MPQ_FILE_COMPRESS):
            return b, raw[:b.size]
        if len(raw) < 4 * (n + 1):
            raise ValueError('missing sector table: %s' % name)
        table = raw[:4 * (n + 1)]
        if key is not None:
            table = _decrypt(table, (key - 1) & 0xFFFFFFFF)
        offsets = list(struct.unpack_from('<%dI' % (n + 1), table, 0))
        out = bytearray()
        for i in range(n):
            start, end = offsets[i], offsets[i + 1]
            if end < start or end > len(raw):
                raise ValueError('bad sector offsets: %s' % name)
            chunk = raw[start:end]
            if key is not None:
                chunk = _decrypt(chunk, (key + i) & 0xFFFFFFFF)
            if b.flags & MPQ_FILE_COMPRESS and len(chunk) < self.sector_size:
                chunk = decompress_sector(chunk, self.sector_size)
            if b.flags & MPQ_FILE_SECTOR_CRC:
                chunk = chunk[:self.sector_size]
            out += chunk
        return b, bytes(out[:b.size])

    def close(self):
        self.f.close()


def decompress_sector(data, sector_size):
    if not data:
        return b''
    mask = data[0]
    if mask == 0:
        return data[1:]
    payload = data[1:]
    if mask & 0x02:
        try:
            return zlib.decompress(payload)
        except zlib.error:
            return zlib.decompress(payload, -15)
    if mask & 0x10:
        return bz2.decompress(payload)
    if mask & 0x01:
        imp = pkware_explode(payload)
        if mask & 0x10:
            imp = bz2.decompress(imp)
        return imp
    raise ValueError('unsupported compression mask 0x%02x' % mask)


def pkware_explode(data):
    """PKWARE DCL explode (compression type 1). Only used by old audio entries."""
    raise ValueError('PKWARE explode is not implemented')


def compress_sector(data):
    c = zlib.compressobj(9, zlib.DEFLATED, -15)
    out = c.compress(data) + c.flush()
    if len(out) + 1 < len(data):
        return b'\x02' + out
    return b'\x00' + data
