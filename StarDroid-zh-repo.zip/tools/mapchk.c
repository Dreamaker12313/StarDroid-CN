#include <stdio.h>
#include <stdlib.h>
#include <StormLib.h>
// extract <map> scenario.chk to <out>; exit 0 on success
int main(int argc,char**argv){
  HANDLE h,f;
  if(argc<3)return 2;
  if(!SFileOpenArchive(argv[1],0,MPQ_OPEN_READ_ONLY,&h)){fprintf(stderr,"open %u\n",GetLastError());return 1;}
  if(!SFileOpenFileEx(h,"staredit\\scenario.chk",SFILE_OPEN_FROM_MPQ,&f)){fprintf(stderr,"chk %u\n",GetLastError());SFileCloseArchive(h);return 1;}
  DWORD size=SFileGetFileSize(f,NULL), got=0;
  char*buf=malloc(size?size:1);
  if(!SFileReadFile(f,buf,size,&got,NULL)||got!=size){fprintf(stderr,"read %u/%u\n",got,size);return 1;}
  FILE*o=fopen(argv[2],"wb"); if(!o)return 1; fwrite(buf,1,size,o); fclose(o);
  SFileCloseFile(f);SFileCloseArchive(h);
  printf("%u\n",size);
  return 0;
}
