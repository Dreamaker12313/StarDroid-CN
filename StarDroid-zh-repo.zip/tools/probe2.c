#include <stdio.h>
#include <stdlib.h>
#include <StormLib.h>
int main(int argc,char**argv){
  HANDLE h; DWORD base=strtoul(argv[2],0,0);
  if(!SFileOpenArchive(argv[1],base,MPQ_OPEN_READ_ONLY,&h)){printf("open fail %u\n",GetLastError());return 1;}
  for(int i=3;i<argc;i++){HANDLE f;printf("%s -> %s\n",argv[i],SFileOpenFileEx(h,argv[i],SFILE_OPEN_FROM_MPQ,&f)?(SFileCloseFile(f),"YES"):"no");}
  SFileCloseArchive(h);return 0;
}
