#!/usr/bin/env python3
"""Rebuild the StarDroid APK from an upstream release APK.

Replaces classes.dex and the localization assets, and bumps the manifest
versionCode by one so the result can overwrite the previous install.

usage: pack_apk.py <template.apk> <classes.dex> <ui-languages.tsv> <zh-hans.ttf> <out.apk>
"""
import struct
import sys
import zipfile


def patch_version_code(manifest):
    """Increment the android:versionCode integer inside the binary XML."""
    data = bytearray(manifest)

    def string_pool(off):
        _, _, _ = struct.unpack_from('<HHI', data, off)
        count, _, flags, strings_start, _ = struct.unpack_from('<IIIII', data, off + 8)
        utf8 = (flags & 0x100) != 0
        base = off + strings_start
        out = []
        for i in range(count):
            pos = base + struct.unpack_from('<I', data, off + 28 + 4 * i)[0]
            if utf8:
                pos += 1
                length = data[pos]
                pos += 1
                if length & 0x80:
                    length = ((length & 0x7F) << 8) | data[pos]
                    pos += 1
                out.append(bytes(data[pos:pos + length]).decode('utf-8', 'replace'))
            else:
                length = struct.unpack_from('<H', data, pos)[0]
                pos += 2
                if length & 0x8000:
                    length = ((length & 0x7FFF) << 16) | struct.unpack_from('<H', data, pos)[0]
                    pos += 2
                out.append(bytes(data[pos:pos + 2 * length]).decode('utf-16-le', 'replace'))
        return out

    names = None
    pos = 8
    while pos + 8 <= len(data):
        kind, header, size = struct.unpack_from('<HHI', data, pos)
        if size < 8:
            break
        if kind == 0x0001:                      # string pool
            names = string_pool(pos)
        elif kind == 0x0102:                    # start element
            attr_start, attr_size, attr_count = struct.unpack_from('<HHH', data, pos + 24)
            for i in range(attr_count):
                at = pos + header + attr_start + i * attr_size
                name_index = struct.unpack_from('<I', data, at + 4)[0]
                if names and names[name_index] == 'versionCode':
                    value = struct.unpack_from('<I', data, at + 16)[0]
                    struct.pack_into('<I', data, at + 16, value + 1)
                    print('versionCode %d -> %d' % (value, value + 1))
        pos += size
    return bytes(data)


def main():
    if len(sys.argv) != 6:
        raise SystemExit(__doc__)
    template, dex, tsv, font, out = sys.argv[1:6]
    replace = {
        'classes.dex': open(dex, 'rb').read(),
        'assets/native/ui-languages.tsv': open(tsv, 'rb').read(),
        'AndroidManifest.xml': patch_version_code(
            zipfile.ZipFile(template).read('AndroidManifest.xml')),
    }
    extra = {'assets/native/zh-hans.ttf': open(font, 'rb').read()}
    source = zipfile.ZipFile(template)
    with zipfile.ZipFile(out, 'w') as target:
        for item in source.infolist():
            data = replace.pop(item.filename, None)
            if data is None:
                if item.filename in extra:
                    continue
                data = source.read(item.filename)
            info = zipfile.ZipInfo(item.filename, date_time=item.date_time)
            info.compress_type = item.compress_type
            info.external_attr = item.external_attr
            info.create_system = item.create_system
            target.writestr(info, data)
        for name, data in extra.items():
            info = zipfile.ZipInfo(name, date_time=(2024, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            target.writestr(info, data)
    if replace:
        raise SystemExit('template is missing: %s' % ', '.join(replace))
    print('wrote', out)


if __name__ == '__main__':
    main()
