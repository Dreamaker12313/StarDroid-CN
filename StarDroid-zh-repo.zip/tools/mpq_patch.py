"""Add/replace one stored file inside a classic (v0/v1) MPQ archive.

The archive keeps its file data; new blocks and rebuilt tables are appended and
the 32-byte header is rewritten in place, which every Storm implementation
(and the engine's own mmap reader) picks up on the next open.
"""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mpq


def patch(archive_path, name, data):
    m = mpq.MPQ(archive_path)
    with open(archive_path, 'rb+') as f:
        f.seek(0, os.SEEK_END)
        size = f.tell()

        def align(n, boundary=0x1000):
            return (n + boundary - 1) // boundary * boundary

        data_offset = align(size)
        f.seek(data_offset)
        f.write(data)
        new_size = data_offset + len(data)

        entry = m.find(name)
        if entry is None:
            raise SystemExit('no existing hash entry for %s' % name)
        block_index = entry.block

        blocks = [mpq.BlockEntry(b.offset, b.compressed_size, b.size, b.flags) for b in m.block_table]
        blocks[block_index] = mpq.BlockEntry(data_offset, len(data), len(data), mpq.FILE_EXISTS)

        block_pos = align(new_size)
        block_raw = b''.join(b.pack() for b in blocks)
        f.seek(block_pos)
        f.write(mpq._encrypt(block_raw, mpq._hash('(block table)', 3)))
        new_size = block_pos + len(block_raw)

        hash_pos = align(new_size)
        hash_raw = b''.join(e.pack() for e in m.hash_table)
        f.seek(hash_pos)
        f.write(mpq._encrypt(hash_raw, mpq._hash('(hash table)', 3)))
        new_size = hash_pos + len(hash_raw)

        sector_shift = 3
        header = struct.pack('<4sIIHHIIII', b'MPQ\x1a', 32, new_size, m.version, sector_shift,
                             hash_pos, block_pos, m.hash_count, len(blocks))
        f.seek(0)
        f.write(header)
        f.flush()
        os.fsync(f.fileno())
    m.close()
    print('patched %s at %d (%d bytes)' % (name, data_offset, len(data)))


if __name__ == '__main__':
    patch(sys.argv[1], sys.argv[3], open(sys.argv[2], 'rb').read())
