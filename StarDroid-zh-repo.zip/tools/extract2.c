#include <stdio.h>
#include <stdlib.h>
#include <StormLib.h>
/* extract2 <archive> <base> <name> <out> */
int main(int argc,char**argv){
  HANDLE h,f; DWORD base=strtoul(argv[2],0,0);
  if(!SFileOpenArchive(argv[1],base,MPQ_OPEN_READ_ONLY,&h)){fprintf(stderr,"open %u\n",GetLastError());return 1;}
  if(!SFileOpenFileEx(h,argv[3],SFILE_OPEN_FROM_MPQ,&f)){fprintf(stderr,"file %u\n",GetLastError());SFileCloseArchive(h);return 1;}
  DWORD size=SFileGetFileSize(f,NULL);
  char*buf=malloc(size?size:1); DWORD got=0;
  if(!SFileReadFile(f,buf,size,&got,NULL)||got!=size){fprintf(stderr,"read %u/%u\n",got,size);return 1;}
  FILE*o=fopen(argv[4],"wb"); fwrite(buf,1,size,o); fclose(o);
  SFileCloseFile(f);SFileCloseArchive(h);return 0;
}
