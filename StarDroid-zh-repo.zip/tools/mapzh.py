"""Rewrite the STR string table of a StarCraft .scm/.scx map and store the
rebuilt scenario.chk back into the map's MPQ container."""
import os
import struct
import subprocess
import sys
import zlib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mpq

CHK_NAME = 'staredit\\scenario.chk'
SECTOR = 4096
EXTRACT = '/root/scwork/mapchk'


def read_chk(map_path):
    tmp = '/tmp/maps/chk-out.bin'
    r = subprocess.run([EXTRACT, map_path, tmp], capture_output=True)
    if r.returncode != 0:
        raise RuntimeError('cannot read scenario.chk: %s' % r.stderr[:80])
    return open(tmp, 'rb').read()


def split_chunks(chk):
    chunks = []
    p = 0
    while p + 8 <= len(chk):
        name = chk[p:p + 4]
        size = struct.unpack_from('<I', chk, p + 4)[0]
        if p + 8 + size > len(chk):
            raise ValueError('truncated chunk %r' % name)
        chunks.append([name, bytearray(chk[p + 8:p + 8 + size])])
        p += 8 + size
    return chunks


def join_chunks(chunks):
    out = bytearray()
    for name, payload in chunks:
        out += name + struct.pack('<I', len(payload)) + payload
    return bytes(out)


def string_entries(payload):
    count = struct.unpack_from('<H', payload, 0)[0]
    offs = [struct.unpack_from('<H', payload, 2 + 2 * i)[0] for i in range(count)]
    out = []
    for o in offs:
        end = payload.find(b'\x00', o)
        if end < 0:
            end = len(payload)
        out.append(bytes(payload[o:end]))
    return out


def rebuild_str(payload, mapping, stats):
    entries = string_entries(payload)
    rebuilt = []
    for raw in entries:
        text = raw.decode('cp1252', 'replace')
        stripped = ''.join(ch for ch in text if ch >= ' ' or ch in '\n\t').replace('\t', ' ').strip()
        hit = mapping.get(stripped)
        if hit is None:
            rebuilt.append(raw)
            continue
        prefix = b''
        for b in raw:
            if b < 32 and b not in (9, 10):
                prefix += bytes([b])
            else:
                break
        rebuilt.append(prefix + hit.encode('utf-8'))
        stats[0] += 1
    if len(rebuilt) > 0xFFFF:
        raise ValueError('too many strings')
    count = len(rebuilt)
    offset_table = 2 + 2 * count
    offsets = []
    position = 0
    for s in rebuilt:
        offsets.append(offset_table + position)
        position += len(s) + 1
    if offset_table + position > 0xFFFF:
        raise ValueError('string table too large: %d' % (offset_table + position))
    body = bytearray()
    body += struct.pack('<H', count)
    for o in offsets:
        body += struct.pack('<H', o)
    for s in rebuilt:
        body += s + b'\x00'
    if len(body) > 0xFFFF:
        raise ValueError('string table too large: %d' % len(body))
    return bytes(body)


FORCE_STORED = False
ZLIB_WRAPPER = True


def compress_block(data):
    if FORCE_STORED:
        return data
    n = (len(data) + SECTOR - 1) // SECTOR
    sectors = []
    for i in range(n):
        chunk = data[i * SECTOR:(i + 1) * SECTOR]
        c = zlib.compressobj(9, zlib.DEFLATED, 15 if ZLIB_WRAPPER else -15)
        comp = c.compress(chunk) + c.flush()
        sectors.append(b'\x02' + comp if len(comp) + 1 < len(chunk) else b'\x00' + chunk)
    table_len = 4 * (n + 1)
    offsets = []
    pos = table_len
    for s in sectors:
        offsets.append(pos)
        pos += len(s)
    offsets.append(pos)
    table = b''.join(struct.pack('<I', o) for o in offsets)
    return table + b''.join(sectors)


def write_block(archive_path, data):
    m = mpq.MPQ(archive_path)
    entry = m.find(CHK_NAME)
    if entry is None:
        raise RuntimeError('no scenario.chk hash entry')
    block = m.block_table[entry.block]
    payload = compress_block(data)
    with open(archive_path, 'r+b') as f:
        if len(payload) <= block.compressed_size and block.offset + block.compressed_size <= m.size:
            f.seek(block.offset)
            f.write(payload)
            f.write(b'\x00' * (block.compressed_size - len(payload)))
            m.block_table[entry.block] = mpq.BlockEntry(
                block.offset, len(payload), len(data), mpq.FILE_EXISTS | mpq.MPQ_FILE_COMPRESS)
            raw = b''.join(b2.pack() for b2 in m.block_table)
            f.seek(m.block_pos)
            f.write(mpq._encrypt(raw, mpq._hash('(block table)', 3)))
            mode = 'inplace'
        else:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            offset = (size + 0xfff) // 0x1000 * 0x1000
            f.seek(offset)
            f.write(payload)
            new_size = offset + len(payload)
            blocks = [mpq.BlockEntry(b.offset, b.compressed_size, b.size, b.flags) for b in m.block_table]
            blocks[entry.block] = mpq.BlockEntry(offset, len(payload), len(data),
                                                 mpq.FILE_EXISTS | mpq.MPQ_FILE_COMPRESS)
            block_pos = (new_size + 0xfff) // 0x1000 * 0x1000
            f.seek(block_pos)
            raw = b''.join(b2.pack() for b2 in blocks)
            f.write(mpq._encrypt(raw, mpq._hash('(block table)', 3)))
            new_size = block_pos + len(raw)
            hash_pos = (new_size + 0xfff) // 0x1000 * 0x1000
            f.seek(hash_pos)
            hraw = b''.join(e.pack() for e in m.hash_table)
            f.write(mpq._encrypt(hraw, mpq._hash('(hash table)', 3)))
            new_size = hash_pos + len(hraw)
            f.seek(0)
            f.write(struct.pack('<4sIIHHIIII', b'MPQ\x1a', 32, new_size, m.version, 3,
                                hash_pos, block_pos, m.hash_count, len(blocks)))
            mode = 'append'
        f.flush()
        os.fsync(f.fileno())
    m.close()
    return mode


def localize(map_path, mapping, stats):
    chk = read_chk(map_path)
    chunks = split_chunks(chk)
    changed = False
    for chunk in chunks:
        if chunk[0] == b'STR ':
            chunk[1] = bytearray(rebuild_str(chunk[1], mapping, stats))
            changed = True
    if not changed:
        return 'no-str'
    return write_block(map_path, join_chunks(chunks))
