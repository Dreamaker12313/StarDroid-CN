# 复现步骤 · Build guide

本文件说明如何从上游 StarDroid 1.1 + 自备游戏文件，重现本汉化版的 APK 与汉化数据。

环境：Ubuntu 24.04 / arm64（x86_64 同样适用），Python 3.10+。

---

## 0. 工具链

```bash
sudo apt-get update
sudo apt-get install -y openjdk-17-jdk-headless unzip p7zip-full \
                        python3-fonttools libstorm-dev gcc libc6-dev

# Android 平台 jar 与 d8/apksigner（只需 android.jar 与 build-tools 里的两个 jar）
curl -O https://dl.google.com/android/repository/platform-35_r02.zip
curl -O https://dl.google.com/android/repository/build-tools_r35_linux.zip
```

> `libstorm-dev` 只用于**验证** MPQ（`SFileOpenArchive` 能打开我们写出的归档），
> 运行时游戏并不依赖它。

自检：

```bash
./tools/probe2 <某个.mpq> <MPQ 起始偏移> "路径\\文件名"   # 只需 gcc + -lstorm 编译
```

---

## 1. 生成 APK

```bash
# 1.1 取上游源码
unzip StarDroid-main.zip && cd StarDroid-main

# 1.2 应用汉化源码（也可直接 git apply patches/zh-localization.diff）
cp -r <repo>/src/*.java app/src/main/java/org/openbw/androidtest/
cp <repo>/src/assets/native/ui-languages.tsv app/src/main/assets/native/
cp <repo>/src/assets/native/zh-hans.ttf     app/src/main/assets/native/

# 1.3 生成 BuildConfig（上游由 Gradle 生成）
cat > app/src/main/java/org/openbw/androidtest/BuildConfig.java <<'EOF'
package org.openbw.androidtest;
public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String APPLICATION_ID = "org.openbw.androidtest";
  public static final String BUILD_TYPE = "release";
  public static final int VERSION_CODE = 85;
  public static final String VERSION_NAME = "1.1-zh";
}
EOF

# 1.4 编译 + dex
mkdir -p build/classes build/dex
javac -nowarn -source 8 -target 8 -encoding UTF-8 \
      -classpath $SDK/platforms/android-35/android.jar \
      -d build/classes $(find app/src/main/java -name '*.java')

java -cp $BT/lib/d8.jar com.android.tools.r8.D8 --release --min-api 26 \
     --lib $SDK/platforms/android-35/android.jar \
     --output build/dex $(find build/classes -name '*.class')

# 1.5 以上游 APK 为模板重新打包（classes.dex / assets / AndroidManifest.xml）
#     manifest 只需把 versionCode 递增（二进制 XML 里 versionCode 属性是 4 字节整数，
#     找到 name 字符串索引指向 "versionCode" 的 attribute，改写其 data 字段即可）
python3 tools/pack_apk.py 上游.apk build/dex/classes.dex \
        app/src/main/assets/native/ui-languages.tsv \
        app/src/main/assets/native/zh-hans.ttf 输出-unsigned.apk

# 1.6 签名
keytool -genkeypair -keystore zh.jks -alias stardroid -keyalg RSA -keysize 2048 \
        -validity 10000 -storepass <pw> -keypass <pw> -dname "CN=StarDroid Chinese"
java -jar $BT/lib/apksigner.jar sign --ks zh.jks --ks-pass pass:<pw> \
        --key-pass pass:<pw> --v1-signing-enabled true --v2-signing-enabled true \
        --out StarDroid-1.1-zh.apk 输出-unsigned.apk
```

---

## 2. 生成中文字库

```bash
# 字符集 = GB2312 全字集 + ASCII + 常用符号 + 所有译文用字（见 tools/font-chars.txt）
python3 -m fontTools.subset /system/fonts/NotoSansCJK-Regular.ttc \
    --font-number=2 --text-file=tools/font-chars.txt \
    --output-file=zh-hans.ttf --no-hinting --layout-features='' --desubroutinize
# 生成物约 3 MB，放在 assets/native/zh-hans.ttf
```

> `NotoSansCJK-Regular.ttc` 的面顺序：0=JP、1=KR、2=SC、3=TC、4=HK。

---

## 3. 生成汉化地图包（613 张 .scm/.scx）

```bash
python3 tools/build_maps.py     # 读 Maps.zip，写 out_maps/ 与 Maps-zh.zip
```

流程：`StormLib` 解出 `staredit\scenario.chk` → 重建 `STR ` 表（`tools/mapzh.py`）
→ zlib 扇区压缩 → 写回原 MPQ（放得下原地覆盖，否则追加并重写表）。
需要 `translations/maps/*.zh.tsv`（译文）与 `Maps.zip`（玩家自有地图）。

---

## 4. 生成汉化战役数据

```bash
# 4.1 定位 MPQ：INSTALL.EXE 内嵌归档头在 0x3F600（259584），BroodWar.mpq 在 0x40980（264704）
python3 - <<'EOF'
import struct
for path in ['INSTALL.EXE','BroodWar.mpq']:
    data=open(path,'rb').read(4*1024*1024)
    for off in range(0,len(data)-32,512):
        if data[off:off+4]==b'MPQ\x1a':
            hs,size,ver,shift,hpos,bpos,hc,bc=struct.unpack_from('<IIHHIIII',data,off+4)
            if hs==32 and ver==0 and hc and hc&(hc-1)==0: print(path, off, hc, bc)
EOF

# 4.2 提取战役地图与剧情文本（extract2.c 支持 MPQ 起始偏移）
gcc -O2 -o extract2 tools/extract2.c -lstorm
./extract2 INSTALL.EXE 259584 "campaign\\terran\\terran01\\staredit\\scenario.chk" terran01.chk
./extract2 BroodWar.mpq 264704 "rez\\estt01.txt" estt01.txt
# 任务路径清单见上游 app/src/main/assets/native/missions.json

# 4.3 重建 STR 并写回归档
python3 tools/patch_campaign.py   # 需要 translations/campaign/*.zh.tsv 与 story_zh.py
```

产物：汉化后的 `StarCraft.mpq`（从 INSTALL.EXE 偏移 259584 起截取）与 `BroodWar.mpq`。

---

## 4.5 中文配音包

配音包是**同结构的中文录音版数据包**：

```
中文语音/StarDat.mpq  ->  改名为 STARDAT_ZH.MPQ
中文语音/BrooDat.mpq  ->  改名为 BROODAT_ZH.MPQ
```

要求：块表条目数与英文版一致（StarDat 2924 块 / BrooDat 946 块），
`rez\stat_txt.tbl`、字体等文本数据保持原版，只有语音 wav 不同。
可用 `tools/probe2` 与 `tools/mpq.py` 快速核对：

```bash
python3 - <<'EOF'
import sys; sys.path.insert(0,'tools'); import mpq
for p in ['STARDAT_ZH.MPQ','BROODAT_ZH.MPQ']:
    m=mpq.MPQ(p); used=[e.block for e in m.hash_table if e.block!=0xFFFFFFFF and e.block<len(m.block_table)]
    print(p, m.hash_count, m.block_count, len(used), m.size)
EOF
```

### 代码接线（共 3 处）

1. `MainActivity.VOICE_MPQS = {"STARDAT_ZH.MPQ","BROODAT_ZH.MPQ"}`，
   `canonical()` 白名单放行这两个名字，`importOne()` 原样存进游戏数据目录；
2. `MainActivity.chooseVoice()`：设置项 `voice-zh`，并在「应用选项 → 配音语言」里切换；
3. `NativeSurface.loadArchives()`：按 `voice-zh` 为 0/1 号归档槽选择
   `STARDAT_ZH.MPQ` / `BROODAT_ZH.MPQ` 或原版文件。

切换在下一次进入任务/开局时生效；文字语言与配音语言互不影响。

---

## 5. 汉化词典

`ui-languages.tsv` 的 6 列结构：

```
英文原文 \t ru \t de \t es \t fr \t 简体中文
```

词典内容 = 上游 741 条界面文案 + stat_txt 全部条目（含母巢之战新增）+ HUD/命令说明标签
+ 80 条帮助提示 + 原版对话框标签。没有的条目就保持英文，随时可以追加。
生成脚本思路：把 `stat_txt` 逐条对照译文、按「英文 → 中文」写入第 6 列，其余列沿用原文。

---

## 6. 验证

```bash
# MPQ：能被 StormLib 打开、能逐条读回
./tools/probe2 汉化.mpq 0 "campaign\\terran\\terran01\\staredit\\scenario.chk"
./extract2 汉化.mpq 0 "campaign\\terran\\terran01\\staredit\\scenario.chk" back.chk
python3 - <<'EOF'
import sys; sys.path.insert(0,'tools'); import mapzh
chk=open('back.chk','rb').read()
for n,p in mapzh.split_chunks(chk):
    if n==b'STR ':
        s=[x.decode('utf-8','ignore') for x in mapzh.string_entries(p)]
        print('条目',len(s),'去重',len(set(s)),'含中文',sum(any('\u4e00'<=c<='\u9fff' for c in x) for x in s))
EOF

# 地图：613 张全部重打包后仍能被 StormLib 读出 scenario.chk
for f in out_maps/**/*.sc?; do ./extract2 "$f" 0 "staredit\\scenario.chk" /tmp/x.chk || echo BAD "$f"; done
```

词典自检（不装 Android 也能跑）：`PortText` 只依赖 `java.*`，写个 main 即可：

```java
PortText.load(new FileInputStream("src/assets/native/ui-languages.tsv"));
PortText.select("zh");
for (String s : new String[]{"Terran Marine", "Objectives", "Start", "Psi Used: 4"})
    System.out.println(s + " => " + PortText.text(s));
```

---

## 7. 发布注意

- **不要提交** `StarCraft.mpq` / `BroodWar.mpq` / `StarDat.mpq` / `Maps-zh.zip` 等游戏数据，
  它们是暴雪版权内容；请放在 Release 里让玩家用自己文件生成，或干脆只发 APK。
- 发布 APK 时递增 `versionCode`，玩家才能覆盖安装。
- 签名密钥自行保管；更换密钥意味着玩家必须卸载重装。
