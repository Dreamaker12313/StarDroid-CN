# 第三方组件与许可 · Third-party notices

本仓库是 [StarDroid](https://github.com/kinopiowarrior/StarDroid) 的**非官方简体中文汉化补丁**，
只包含汉化代码、词典、字库与处理脚本。**不包含任何 Blizzard Entertainment 的游戏数据。**

StarCraft、StarCraft: Brood War 及相关名称、图像、音频、文本版权归 Blizzard Entertainment 所有。
本项目与 Blizzard Entertainment 无任何隶属或授权关系。请使用自己合法拥有的游戏文件。

---

## 上游与组件

| 组件 | 来源 | 许可 / 说明 |
| --- | --- | --- |
| StarDroid 1.1 | ToadWarrior，<https://github.com/kinopiowarrior/StarDroid> | 上游未声明统一开源许可证；本仓库为独立补丁，不重新授权其代码 |
| OpenBW | <https://github.com/OpenBW/openbw>、<https://github.com/heiner/openbw> | 上游仓库未附顶层许可证文件；本项目未修改、未重新授权引擎 |
| libsmacker 1.2.0 | Greg Kennedy / JonnyH/libsmacker | LGPL-2.1-or-later（随上游 APK 分发，本汉化未改动） |
| PyMS 任务清单 / 格式参考 | Zach Zahos (poiuyqwert/PyMS) | MIT |
| Weave 地图 | Alexandre Coderre-Chabot (acodcha/sc) | CC BY 4.0（上游自带示例图） |
| Noto Sans CJK SC（子集） | Google / Adobe，<https://github.com/notofonts/noto-cjk> | **SIL Open Font License 1.1**，见下 |
| StormLib | Ladislav Zezula | 仅作为**本地校验工具**编译使用，不随产物分发 |
| fontTools | <https://github.com/fonttools/fonttools> | MIT，用于生成字库子集 |

---

## 内置字库

`src/assets/native/zh-hans.ttf` 是 **Noto Sans CJK SC Regular** 的子集
（GB2312 全字集 + ASCII + 常用符号 + 本汉化译文用字，共 7572 个字符），
按 **SIL Open Font License 1.1** 使用与再分发：

```
Copyright 2014-2021 Adobe (http://www.adobe.com/), with Reserved Font Name 'Source'.
Noto is a trademark of Google Inc.

This Font Software is licensed under the SIL Open Font License, Version 1.1.
This license is available with a FAQ at: https://scripts.sil.org/OFL
```

OFL 允许子集化、嵌入与再分发，要求：保留版权与许可声明；不得单独售卖字体；
不得使用保留字体名（Reserved Font Name）作为修改后字体的名称。
本子集文件名为 `zh-hans.ttf`，未使用 `Source` / `Noto` 作为字体名的一部分。

---

## 翻译文本

`translations/`、`src/assets/native/ui-languages.tsv` 中的中文译文由本项目翻译，
采用与上游中文社区一致的术语习惯（人族 / 虫族 / 神族、陆战队员、刺蛇、龙骑士…）。
地图与战役剧情译文是对玩家自有游戏数据内文本的转换，仅供个人使用，请勿再分发游戏数据本身。
